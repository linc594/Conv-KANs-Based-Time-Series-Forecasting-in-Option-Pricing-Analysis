import argparse
import numpy as np
import torch
from os.path import isdir
import os
from core.models_lstm import LSTM
from core.functions import *
from torch.utils import data
from torch import nn, optim
from datetime import datetime
import matplotlib.pyplot as plt
from tqdm import tqdm

torch.backends.cudnn.deterministic = True
torch.backends.cudnn.benchmark = False

def get_data(data_input, data_label, args):
    # data_input:(N, C, T, D), data_label:(N, T, 1)
    data_loader = data.DataLoader(data.TensorDataset(data_input, data_label), batch_size=args.batch_size, shuffle=False, drop_last=False)
    return data_loader

def get_models(args):
    if args.test_checkpoint is None:
        net = LSTM(in_dim=9, in_channels=1, out_dim=1, seq_len=1)
        optimizer = optim.Adam(list(net.parameters()), amsgrad=True, lr=args.learning_rate)
    else:
        try:
            net = torch.load(r"C:\Users\Desktop\experiment\main\checkpoints\\Oct16_092116_net",weights_only=False) #Please modify these paths as needed
            optimizer = torch.load(r"C:\Users\Desktop\experiment\main\checkpoints\\Oct16_092116_optimizer",weights_only=False) #Please modify these paths as needed
        except FileNotFoundError: 
            try:
                net = torch.load(args.test_checkpoint + "_net")
                optimizer = torch.load(args.test_checkpoint + "_optimizer")
            except:
                print("No checkpoint found at '{}'- Please specify the model for testing".format(args.test_checkpoint))
                exit()

    if torch.cuda.is_available():
        net.cuda()

    return net, optimizer

def test(test_loader, args):
    model, _ = get_models(args)
    criterion = nn.MSELoss()
    model.eval()

    true_price = []
    estimate_price = []

    test_loss = []
    test_map = []
    test_mape = []
    test_property_corr = []

    model.eval()
    print("\nTesting the model")
    with torch.no_grad():
        for x, y in test_loader:
            y_hat = model(x)

            loss = criterion(y_hat, y)
            corr, map, mape = metrics(y_hat.detach(), y.detach())

            test_loss.append(loss.item())
            test_map.append(map)
            test_mape.append(mape)
            test_property_corr.append(corr)

            true_price.append(y.detach())
            estimate_price.append(y_hat.detach())

        property_corr = torch.mean(torch.cat(test_property_corr, dim=0)).squeeze().float().cuda()
        map = torch.mean(torch.cat(test_map, dim=0)).squeeze().float().cuda()
        mape = torch.mean(torch.cat(test_mape, dim=0)).squeeze().float().cuda()
        loss = torch.mean(torch.tensor(test_loss)).float().cuda()
        rmse = torch.sqrt(loss)
        print("MSE: {:.5f}\nRMSE: {:0.5f}\nMAP: {:0.5f}\nMAPE: {:0.5f}\nCorrelation: {:0.5f}\n".format(loss, rmse, map, mape, property_corr))

        # shape:(N, T, D_out=3)
        true_price = torch.cat(true_price, dim=0)
        estimate_price = torch.cat(estimate_price, dim=0)

        true_price = true_price.cpu()
        estimate_price = estimate_price.cpu()

        true_price = true_price.numpy()
        estimate_price = estimate_price.numpy()

        plot_len = 240
        plt.plot(np.arange(plot_len), true_price[0:plot_len], color='blue', label="True Price")
        plt.plot(np.arange(plot_len), estimate_price[0:plot_len], color='red', label="Estimated Price")
        plt.legend()
        plt.xlabel('Time')
        plt.ylabel('Option Price')
        plt.title("Comparison of Estimated Price and True Price")

        plt.show()


if __name__ == '__main__':
    ## Arguments and parameters
    parser = argparse.ArgumentParser()
    
    parser.add_argument('-batch_size', type=int, default=32, help="Batch size for training")
   
    parser.set_defaults(test_checkpoint="Oct15_182159")
    args = parser.parse_args()
    


    test_input = torch.load(r"C:\Users\Desktop\experiment\core\torch-data\test_input.pt", weights_only=True).float().cuda()  
    test_input_mean = torch.mean(test_input, dim=0, keepdim=True)
    test_input_std = torch.std(test_input, dim=0, keepdim=True)
    test_input_normalization = Normalization(test_input_mean, test_input_std)
    test_input = test_input_normalization.normalize(test_input)

    test_label = torch.load(r"C:\Users\Desktop\experiment\core\torch-data\test_label.pt", weights_only=True).float().cuda()
    test_label_mean = torch.mean(test_label, dim=0, keepdim=True)
    test_label_std = torch.std(test_label, dim=0, keepdim=True)
    test_label_normalization = Normalization(test_label_mean, test_label_std)
    test_label = test_label_normalization.normalize(test_label)

    test_input = test_input.reshape(test_input.shape[0], 1, test_input.shape[2], test_input.shape[1] * test_input.shape[3])

    test_loader = get_data(test_input, test_label, args)

    test(test_loader, args)