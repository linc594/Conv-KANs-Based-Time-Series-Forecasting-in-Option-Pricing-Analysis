from torch import nn
import torch.nn.functional as F

from efficient_kan.convkan import KAN_Convolutional_Layer
from efficient_kan.kan import KANLinear

class KKAN_Convolutional_Network(nn.Module):
    def __init__(self,device,in_dim, out_dim):
        super().__init__()
        self.conv1 = KAN_Convolutional_Layer(
            n_convs = 1,
            kernel_size= (3,3),
            device = device
        )

        self.conv2 = KAN_Convolutional_Layer(
            n_convs = 1,
            kernel_size = (3,3),
            device = device
        )


        self.pool1 = nn.MaxPool2d(
            kernel_size=(1, 3)
        )
        
        self.flat = nn.Flatten() 

        self.kan1 = KANLinear(
            9,
            1,
            grid_size=10,
            spline_order=3,
            scale_noise=0.01,
            scale_base=1,
            scale_spline=1,
            base_activation=nn.SiLU,
            grid_eps=0.02,
            grid_range=[0,1],
        )
        self.linear = nn.Linear(in_features=in_dim, out_features=out_dim)

    def forward(self, x):
        x = self.conv1(x)
        #x = self.pool1(x)
        #x = self.conv2(x)
        #x = self.pool1(x)
        x = self.flat(x)
        #x = self.kan1(x) 
        x = self.linear(x)
        return x.squeeze()